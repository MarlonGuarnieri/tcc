<?php
include "painelAdministrador.php";
?>

<!DOCTYPE html>


    <meta charset="utf-8"> 
	
    <meta name="viewport" content="width=device-width, initial-scale=1"> 	
	
    <meta name="author" content="sumit kumar"> 
	
    <title>admin-template</title> 
	
    <link href="assets/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
	
    <link href="assets/bootstrap/css/font-awesome.css" rel="stylesheet" type="text/css">	
	
    <link href="assets/bootstrap/css/style.css" rel="stylesheet" type="text/css">

	<link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- CSS do Projeto -->
    <link href="assets/css/pginicioProfessor.css" rel="stylesheet" type="text/css">



    
 <div class="container-fluid">
	<div class="row">

		<section class="content">
<!--			-->

				</div>
			</div>
		</section>
		
	</div>
</div>
    
    
    
    
    
    
    
    <script src="js/jquery-3.1.1.js"></script>    
    <script src="js/bootstrap.js"></script>

