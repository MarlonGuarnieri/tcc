<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 02/04/18
 * Time: 15:47
 */

class Conexao {

    const HOST      = "localhost";
    const NOMEBANCO = "gamif";
    const USUARIO   = "admin";
    const SENHA     = "";

    public static function getConexao(){
        //Conexão com o banco de dados usando o objeto PDO
        $conexao = new PDO("mysql:host=".self::HOST.";dbname=".self::NOMEBANCO, self::USUARIO, self::SENHA);
        //Me retorne a conexão
        return $conexao;
    }
}