<?php
require_once __DIR__."/../model/Login.php";
include "menu.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Classificação</title>

    <!-- Bootstrap -->

    <link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/fonts/lora.css" rel="stylesheet" type="text/css">
    <link href="../../assets/fonts/montserrat.css" rel="stylesheet" type="text/css">
    <link href="../../assets/css/menu.css" rel="stylesheet" type="text/css">


    <!-- Local -->

    <link href="">
</head>



</nav>

<div class="container">
	<div class="row">
		<h2>Ranking</h2>
	</div>

	<table class="table table-fixed table-striped" border="1px";>
	    <thead>
	        <tr>
	            <th>Posição</th>
	            <th>Pontos</th>
	            <th>Nome</th>
	            <th>Instituição</th>
	            <th>Ano Escolar</th>
	            
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>720</td>
                <td>José</td>
                <td>Instituto Federal Catarinense</td>
                <td>quarto ano</td>
            </tr>
            <tr>
                <td>2</td>
                <td>675</td>
                <td>Rodolfo</td>
                <td>Almirante Boiteux</td>
                <td>terceiro ano</td>
            </tr>
            <tr>
                <td>3</td>
                <td>670</td>
                <td>Gustavo</td>
                <td>CAIC Professor Mariano Costa</td>
                <td>terceiro ano</td>
            </tr>

        </tbody>
    </table>
</div>


</html>
