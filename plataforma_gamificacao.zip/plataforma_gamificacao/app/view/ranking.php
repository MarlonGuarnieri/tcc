<?php require_once __DIR__."/../model/Login.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Classificação</title>

    <!-- Bootstrap -->

    <link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/fonts/lora.css" rel="stylesheet" type="text/css">
    <link href="../../assets/fonts/montserrat.css" rel="stylesheet" type="text/css">
    <link href="../../assets/css/menu.css" rel="stylesheet" type="text/css">


    <!-- Local -->

    <link href="">



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>


<body><nav class="navbar">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="itens navbar-brand" href="#">WebSiteName</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="itens"><a href="#">Home</a></li>
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li class="itens"><a href="#">Page 1-1</a></li>
                    <li class=""><a href="#">Page 1-2</a></li>
                    <li><a href="#">Page 1-3</a></li>
                </ul>
            </li>
            <li><a class="itens" id="inicio">Início </a></li>
            <li><a class="itens" id="disciplinas">Disciplinas </a></li>
            <li><a class="itens" id="configuracoes">Configurações</a></li>
            <li><a class="itens" id="perfil">(Perfil) </a></li>
            <li><a class="itens" id="inicio">Início </a></li>
        </ul>
    </div>
</nav>

<div class="container">
	<div class="row">
		<h2>Ranking entre todas as escolas</h2>
	</div>
	
	<table class="table table-fixed table-striped" border="1px";>
	    <thead>
	        <tr>
	            <th>Posição</th>
	            <th>Pontos</th>
	            <th>Nome</th>
	            <th>Instituição</th>
	            <th>Ano Escolar</th>
	            
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>720</td>
                <td>José</td>
                <td>Instituto Federal Catarinense</td>
                <td>quarto ano</td>
            </tr>
            <tr>
                <td>2</td>
                <td>675</td>
                <td>Rodolfo</td>
                <td>Almirante Boiteux</td>
                <td>terceiro ano</td>
            </tr>
            <tr>
                <td>3</td>
                <td>670</td>
                <td>Gustavo</td>
                <td>CAIC Professor Mariano Costa</td>
                <td>terceiro ano</td>
            </tr>

        </tbody>
    </table>
</div>

</body>
</html>