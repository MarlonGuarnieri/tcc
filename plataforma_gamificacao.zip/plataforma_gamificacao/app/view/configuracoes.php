<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 24/04/2018
 * Time: 08:46
 */

require_once __DIR__."/../model/Login.php";
?>

<html>
<head>
    <!--Local-->
    <link href="../../assets/css/daoAluno.css" rel="stylesheet">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap -->

    <link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/fonts/lora.css" rel="stylesheet" type="text/css">
    <link href="../../assets/fonts/montserrat.css" rel="stylesheet" type="text/css">
    <link href="../../assets/css/menu.css" rel="stylesheet" type="text/css">
    <link href="../../assets/css/daoAluno.css" rel="stylesheet" type="text/css">


</head>
<body>
<!-- Formulário para cadastro de professor.
     Form to register a teacher -->

<div id="formulario" class="form-group container-fluid col-md-4  col-md-offset-4 col-sm-10 col-sm-offset-1">
    <form class="form-cadastro" method = POST action="../controller/controlador_aluno.php?acao=cadastrarAluno">
        <h3>Editar</h3>
        <div class="form-group">
            <label>Nome</label>
            <input class="form-control"  type="text"      name="us_nome" value="">
        </div>

        <div class="form-group">
            <label>Nova Senha</label>
            <input class="form-control" type="password"  name="us_senha" value="">
        </div>

        <div class="form-group">
            <label>Confirmar senha</label>
            <input class="form-control" type="password"  name="confirmar_us_senha" value="">
        </div>

        <div class="form-group">
            <label>Data Nascimento</label>
            <input class="form-control" type="date"      name="us_datanascimento">
        </div>

        <div class="form-group">
            <input class="form-control btn-primary" type="submit" value="Confirmar">
        </div>

    </form>
</div>
</div>
</body>
</html>



