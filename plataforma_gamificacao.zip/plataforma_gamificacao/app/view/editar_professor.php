<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 24/04/2018
 * Time: 08:46
 */
include "menu.php";
require_once __DIR__."/../model/Login.php";
require_once __DIR__."/../dao/dao_professor.php";

$id = $_GET['id'];
$dadosProfessor = new DaoProfessor();

$aluno = $dadosProfessor->getProfessor($id);



?>

<html>
<head>
    <!--Local-->
    <link href="../../assets/css/daoAluno.css" rel="stylesheet">

</head>
<body>
<!-- Formulário para edição de professor.
     Form to edit a teacher -->

<div id="formulario" class="form-group container-fluid col-md-4 col-md-offset-4">
    <form method = POST action="../controller/controlador_professor.php?acao=editarProfessor">
        <h3>Editar Professor</h3>
        <div class="form-group">
            <label>Nome</label>
            <input class="form-control"  type="text"      name="us_nome" placeholder="Digite seu nome aqui" value="<?= $aluno->getUsNome(); ?>">
        </div>

        <div class="form-group">
            <label>E-mail</label>
            <input class="form-control" type="email"     name="us_email" placeholder="E-mail" value="<?= $aluno->getUsEmail() ?>">
        </div>

        <div class="form-group">
            <label>Senha</label>
            <input class="form-control" type="password"  name="us_senha" placeholder="Nova senha" value="<?=$aluno->getUsSenha(); ?>">
        </div>

        <div class="form-group">
            <label>Data Nascimento</label>
            <input class="form-control" type="date"      name="us_datanascimento" value="<?=$aluno->getUsDatanascimento();?>">
        </div>

        <div class="form-group">
            <label>Área</label>
            <select      class="form-control"            name="pr_area">

                <option name="portugues"  value="1"  >Português  </option>
                <option name="matematica" value="2"  >Matemática </option>
                <option name="historia"   value="3"  >História   </option>
                <option name="geografia"  value="4"  >Geografia  </option>
                <option name="ciencias"   value="5"  >Ciências   </option>
                <option name="ingles"     value="6"  >Inglês     </option>
                <option name="artes"      value="7"  >Artes      </option>

            </select>

            <input type="hidden" name="us_idusuario" value="<?=$aluno->getUsIdusuario();?>">

        </div>

        <div class="form-group">
            <input class="form-control btn-primary" type="submit" value="Cadastrar">
        </div>

    </form>
</div>
</body>
</html>
