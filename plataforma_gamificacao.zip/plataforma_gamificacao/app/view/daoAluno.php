<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 24/04/2018
 * Time: 08:46
 */

require_once __DIR__."/../model/Login.php";
?>

<html>
<head>
    <!--Local-->
    <link href="../../assets/css/daoAluno.css" rel="stylesheet">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap -->

    <link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/fonts/lora.css" rel="stylesheet" type="text/css">
    <link href="../../assets/fonts/montserrat.css" rel="stylesheet" type="text/css">
    <link href="../../assets/css/menu.css" rel="stylesheet" type="text/css">
    <link href="../../assets/css/login.css" rel="stylesheet" type="text/css">


</head>
<body>
<!-- Formulário para cadastro de professor.
     Form to register a teacher -->

<div id="formulario" class="form-group container-fluid col-md-4 col-md-offset-4 login-form">
    <form method = POST action="../controller/controlador_aluno.php?acao=cadastrarAluno login-form">
    <h3>Cadastro Aluno</h3>
        <div class="form-group">
            <label>Nome</label>
            <input class="form-control"  type="text"      name="us_nome" placeholder="Digite seu nome aqui">
        </div>

        <div class="form-group">
            <label>E-mail</label>
            <input class="form-control" type="email"     name="us_email" placeholder="Digite seu e-mail">
        </div>

        <div class="form-group">
            <label>Confirmar e-mail</label>
            <input class="form-control" type="email"     name="confirmar_us_email" placeholder="Confirmar e-mail">
        </div>

        <div class="form-group">
            <label>Senha</label>
            <input class="form-control" type="password"  name="us_senha" placeholder="Digite sua senha">
        </div>

        <div class="form-group">
            <label>Confirmar senha</label>
            <input class="form-control" type="password"  name="confirmar_us_senha" placeholder="Confirmar senha">
        </div>

        <div class="form-group">
            <label>Data Nascimento</label>
            <input class="form-control" type="date"      name="us_datanascimento">
        </div>

        <div class="form-group">
            <label>Matrícula</label>
            <input class="form-control" type="text"      name="al_matricula" placeholder="Digite seu número de Matrícula">
        </div>

        <div class="form-group">
            <label>Ano</label>
            <select      class="form-control"            name="al_ano">

                <option name="" value="6"  >Sexto ano  </option>
                <option name="" value="7"  >Sétimo ano </option>
                <option name="" value="8"  >Oitavo ano </option>
                <option name="" value="9"  >Nono ano   </option>

            </select>

        </div>


        <div class="form-group">
            <label>Turma</label>
            <select      class="form-control"            name="al_turma">

                <option name="" value="1"  >A </option>
                <option name="" value="2"  >B </option>
                <option name="" value="3"  >C</option>
                <option name="" value="4"  >D</option>

            </select>

        </div>

        <div class="form-group">
            <input class="form-control btn-primary" type="submit" value="Cadastrar">
        </div>

    </form>
</div>
</div>
</body>
</html>



