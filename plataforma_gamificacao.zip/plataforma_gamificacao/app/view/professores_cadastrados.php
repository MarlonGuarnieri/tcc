<?php
require_once __DIR__."/../model/Login.php";
Login::isLogado();
include "painelAdministrador.php";
require_once __DIR__."/../dao/dao_professor.php";

$daoProfessor = new DaoProfessor();
$professores  = $daoProfessor->getProfessores();
?>
<!DOCTYPE html>

<html lang="en">
    <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="sumit kumar">
    <title>Professores Cadastrados</title>
    <link href="../../assets/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- CSS do Projeto -->
    <link href="../../assets/css/professores_cadastrados.css" rel="stylesheet" type="text/css">
    </head>

 <div class="container-fluid">
	<div class="row">

		<section class="content">
			<h1>Professores Cadastrados</h1>
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="pull-right">
						</div>
						<div class="table-container">
							<table class="table my-table-filter">
								<tbody>
                                <?php foreach($professores as $professor): ?>
									<tr>
										<td>
											<div class="ckbox">
												<input type="checkbox" id="checkbox1">
												<label for="checkbox1"></label>
											</div>
										</td>
										<td>
                                            <a href="../controller/controlador_professor.php?acao=excluirProfessor&pr_idusuario=<?=$professor->getPrIdusuario();?>" class="excluir">
                                                <i class="glyphicon glyphicon-trash"></i>
                                            </a>

                                            <form method="post">
                                            <a href="../view/editar_professor.php?acao=editar&id=<?= $professor->getPrIdusuario();?>" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
										</td>
										<td>
											<div class="media">
												<a href="#" class="pull-left">
													<img src="https://s3.amazonaws.com/uifaces/faces/twitter/fffabs/128.jpg" class="media-photo">
												</a>
												<div class="media-body">
													<span class="media-meta pull-right">Febrero 13, 2016</span>
													<h4 class="title">
                                                       <?php echo($professor->getUsNome());?>
                                                    </h4>

													<p class="summary">

                                                        E-mail: <?= $professor->getUsEmail() ;?>
                                                        Número de Matrícula: <?=$professor->getPrMatricula();?>
                                                        Data Nascimento: <?= $professor->getUsDataNascimento();?>
                                                        Matrícula: <?= $professor->getPrMatricula();?>
                                                        Área: <?= $professor->getPrArea();?>
                                                    </p>
												</div>
											</div>
										</td>
                                        <?php endforeach;?>
									</tr>
							</table>
						</div>
					</div>
				</div>
				<div class="content-footer">
					<p>
						Gamificação © - 2017 <br>
						Powered By Fábio De Moura, Guilherme Cipriano & Marlon Guarnieri
					</p>
				</div>
			</div>
		</section>

	</div>
</div>







    <script src="js/jquery-3.1.1.js"></script>
    <script src="js/bootstrap.js"></script>
