<!DOCTYPE html>

<html lang="en">
    <head>
    
    <meta charset="utf-8"> 
	
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="author" content="sumit kumar">
	
    <title>Inicio</title>
	
    <link href="../../assets/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">

	<link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- CSS do Projeto -->
    <link href="../../assets/css/painelAdministrador.css" rel="stylesheet" type="text/css">


    <body>
        <div class="container-2">
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-title">
                            <h2>Painel de Controle</h2>
       </div>
      </div>
     </div>


         <div class="row" >
                    <!--Alunos Cadastrados-->
            <div class="col-lg-2 col-sm-6">
                <div class="circle-tile">
                    <a href="#">
                        <div class="circle-tile-heading dark-blue">
                            <i class="fa fa-graduation-cap fa-fw fa-3x"></i>
                        </div>
                    </a>
                    <div class="circle-tile-content dark-blue">
                        <div class="circle-tile-description text-faded">
                            Usuários Cadastrados
                        </div>
                        <div class="circle-tile-number text-faded">
                            140
                            <span id="sparklineA"></span>
                        </div>
                        <a href="alunos_cadastrados.php" class="circle-tile-footer">Ver usuários <i class="fa fa-chevron-circle-right"></i></a>
                    </div>
                </div>
            </div>

                    <!--Respostas-->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading green">
                             <i class="fa fa-check fa-fw fa-3x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content green">
                         <div class="circle-tile-description text-faded">
                             Respostas
                         </div>
                         <div class="circle-tile-number text-faded">
                             1024
                         </div>
                         <a href="respostas.php" class="circle-tile-footer">Mais informações <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>
                    <!--Rendimento Dos Estudantes-->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading orange">
                             <i class="fa fa-line-chart fa-fw fa-3x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content orange">
                         <div class="circle-tile-description text-faded">
                             Rendimento dos estudantes
                         </div>
                         <div class="circle-tile-number text-faded">
                             33 Atualizações
                         </div>
                         <a href="#" class="circle-tile-footer">Ver Mais <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>
                    <!--Questões-->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading blue">
                             <i class="fa fa-question fa-fw fa-4x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content blue">
                         <div class="circle-tile-description text-faded">
                             Questões Cadastradas
                         </div>
                         <div class="circle-tile-number text-faded">
                             256
                             <span id="sparklineB"></span>
                         </div>
                         <a href="questoes.php" class="circle-tile-footer">Visualizar por matérias <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>
                <!--Instituições-->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading red">
                             <i class="fa fa-university fa-fw fa-3x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content red">
                         <div class="circle-tile-description text-faded">
                             Instituições
                         </div>
                         <div class="circle-tile-number text-faded">
                             24
                             <span id="sparklineC"></span>
                         </div>
                         <a href="instituicoes_cadastradas.php" class="circle-tile-footer">Ver Instituições <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>

                <!--Perguntas a Analisar -->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading purple">
                             <i class="fa fa-comments fa-fw fa-3x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content purple">
                         <div class="circle-tile-description text-faded">
                             Perguntas a Analisar
                         </div>
                         <div class="circle-tile-number text-faded">
                             96
                             <span id="sparklineD"></span>
                         </div>
                         <a href="analizar_perguntas.php" class="circle-tile-footer">Analisar perguntas <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>
                    <!--Professores Cadastrados-->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading gray">
                             <i class="fa fa-users fa-fw fa-3x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content gray">
                         <div class="circle-tile-description text-faded">
                             Professores Cadastrados
                         </div>
                         <div class="circle-tile-number text-faded">
                             13
                         </div>
                         <a href="professores_cadastrados.php" class="circle-tile-footer">Ver Mais <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>

                <!--Cadastrar ALuno-->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading black">
                             <i class="fa fa-graduation-cap fa-fw fa-2x"></i>
                             <i class="fa fa-plus fa-2x" aria-hidden="true"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content black">
                         <div class="circle-tile-description text-faded">
                             Cadastrar Aluno
                         </div>
                         <div class="circle-tile-number text-faded">
                             13
                         </div>
                         <a href="daoAluno.php" class="circle-tile-footer">Ver Mais <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>

                <!--Cadastrar Professor-->
             <div class="col-lg-2 col-sm-6">
                 <div class="circle-tile">
                     <a href="#">
                         <div class="circle-tile-heading dark-slate-blue">
                             <i class="fa fa-user-plus fa-3x"></i>
                         </div>
                     </a>
                     <div class="circle-tile-content dark-slate-blue">
                         <div class="circle-tile-description text-faded">
                             Cadastrar Professor
                         </div>
                         <div class="circle-tile-number text-faded">
                             13
                         </div>
                         <a href="daoProfessor.php" class="circle-tile-footer">Ver Mais <i class="fa fa-chevron-circle-right"></i></a>
                     </div>
                 </div>
             </div>
         </div>
    </div><!-- page-wrapper END-->
   </div><!-- container-1 END-->

       <script src="js/jquery-3.1.1.js"></script>    
    <script src="js/bootstrap.js"></script>
    </body>

    

