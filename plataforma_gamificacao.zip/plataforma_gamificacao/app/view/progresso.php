
<!DOCTYPE html>
<html>
<head>
	<title>Progresso</title>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap -->

    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/fonts/lora.css" rel="stylesheet" type="text/css">
    <link href="assets/fonts/montserrat.css" rel="stylesheet" type="text/css">

    <!-- Local -->

<style type="text/css">

.menu{
	background-color: #5bc0de;
	color: white;
	text-decoration: none;

}

.lista{
	color: background: rgba(32,166,231,.8);
}

.itens{
	border-radius: 10px;
	text-decoration-color: white;
}

.itens a{
	text-decoration-color: white;
}

#inicio:hover{
	background: rgba(32,166,231,.8);
	color: white;
}
#ranking:hover{
	background: rgba(32,166,231,.8);
	color: white;
}
#disciplinas:hover{
	background: rgba(32,166,231,.8);
	color: white;
}
#configuracoes:hover{
	background: rgba(32,166,231,.8);
	color: white;
}
#perfil:hover{
	background: rgba(32,166,231,.8);
	color: white;
}
body{
	background-color: #e8e8e8;
}

a{
	color: white;
}

.botao {

	float: right;
	margin-left: 5px;
}

.bloco{
	padding-bottom: 20px;
}

.navbar{
	background-color:#5bc0de
}

.footer{

	height: 50px;
	width: 100%;
	background-color: white;

}

.rodape{
	color: #6d6d6d;
	text-align: center;
}

/*Inicia Gráfico Matérias*/

  .shape{
    border-style: solid; border-width: 0 70px 40px 0; float:right; height: 0px; width: 0px;
	-ms-transform:rotate(360deg); /* IE 9 */
	-o-transform: rotate(360deg);  /* Opera 10.5 */
	-webkit-transform:rotate(360deg); /* Safari and Chrome */
	transform:rotate(360deg);
}
.offer{
	background:#fff; border:1px solid #ddd; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); margin: 15px 0; overflow:hidden;border-radius: 10px;
}
.offer:hover {
    -webkit-transform: scale(1.1);
    -moz-transform: scale(1.1);
    -ms-transform: scale(1.1);
    -o-transform: scale(1.1);
    transform:rotate scale(1.1);
    -webkit-transition: all 0.4s ease-in-out;
-moz-transition: all 0.4s ease-in-out;
-o-transition: all 0.4s ease-in-out;
transition: all 0.4s ease-in-out;
    }
.shape {
	border-color: rgba(255,255,255,0) #d9534f rgba(255,255,255,0) rgba(255,255,255,0);
}
.offer-radius{
	border-radius:7px;
}
.offer-danger {	border-color: #d9534f; }
.offer-danger .shape{
	border-color: transparent #d9534f transparent transparent;
}
.offer-success {	border-color: #5cb85c; }
.offer-success .shape{
	border-color: transparent #5cb85c transparent transparent;
}
.offer-default {	border-color: #999999; }
.offer-default .shape{
	border-color: transparent #999999 transparent transparent;
}
.offer-primary {	border-color: #428bca; }
.offer-primary .shape{
	border-color: transparent #428bca transparent transparent;
}
.offer-info {	border-color: #5bc0de; }
.offer-info .shape{
	border-color: transparent #5bc0de transparent transparent;
}
.offer-warning {	border-color: #f0ad4e; }
.offer-warning .shape{
	border-color: transparent #f0ad4e transparent transparent;
}

.offer-purple {	border-color: #5b2597; }
.offer-purple .shape{
	border-color: transparent #5b2597 transparent transparent;
}

.shape-text{
	color:#fff; font-size:12px; font-weight:bold; position:relative; right:-40px; top:2px; white-space: nowrap;
	-ms-transform:rotate(30deg); /* IE 9 */
	-o-transform: rotate(360deg);  /* Opera 10.5 */
	-webkit-transform:rotate(30deg); /* Safari and Chrome */
	transform:rotate(30deg);
}
.offer-content{
	padding:0 20px 10px;
}
@media (min-width: 480px) {
  .container {
    max-width: 750px;
  }
  .col-sm-6 {
    width: 50%;
  }
}
@media (min-width: 900px) {
  .container {
    max-width: 970px;
  }
  .col-md-4 {
    width: 33.33333333333333%;
  }
}

@media (min-width: 1200px) {
  .container {
    max-width: 1170px;
  }
  .col-lg-3 {
    width: 25%;
  }

}

.label {
text-align: center;
}


}

.progress-bar-purple {
  background-color: #5b2597;
}
.progress-striped .progress-bar-purple {
  background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:      -o-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:         linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
}


</style>
</head>
<body>

 <nav class="navbar">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="itens navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="itens"><a href="#">Home</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li class="itens"><a href="#">Page 1-1</a></li>
          <li class=""><a href="#">Page 1-2</a></li>
          <li><a href="#">Page 1-3</a></li>
        </ul>
      </li>
      <li><a class="itens" id="inicio">Início </a></li>
      <li><a class="itens" id="disciplinas">Disciplinas </a></li>
      <li><a class="itens" id="configuracoes">Configurações</a></li>
      <li><a class="itens" id="perfil">(Perfil) </a></li>
      <li><a class="itens" id="inicio">Início </a></li>
    </ul>
  </div>
</nav>

<!--Português-->
<div class="conteudo container-fluid">
<div class="row">   
    		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-danger">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>							
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
						 Português: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>
					
					<h5>
					
					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>
					
					</h5>
				</div>
				</div>
			</div>

			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-danger">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>							
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
						 Português: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>
					
					<h5>
					
					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>
					
					</h5>
				</div>
				</div>
			</div>

			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-danger">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>							
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
						 Português: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>
					
					<h5>
					
					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>
					
					</h5>
				</div>
				</div>
			</div>


		</div>


		<div class="row">
			<div class=" bloco col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="offer offer-danger">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>							
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
						 Português: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>
					
					<h5>
					
					<button class="btn btn-success">Jogar!</button>
					<button class="btn btn-danger">Reforçar!</button>
					
					</h5>
				</div>
				</div>
			</div>


			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-danger">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>							
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
						 Português: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>
					
					<h5>
					
					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>
					
					</h5>
				</div>
				</div>
			</div>

			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-danger">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>							
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
						 Português: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>
					
					<h5>
					
					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>
					
					</h5>
				</div>
				</div>
			</div>
</div>

<div class="row">
			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-danger">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>							
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
						 Português: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>
					
					<h5>
					
					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>
					
					</h5>
				</div>
				</div>
			</div>

<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-danger">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>							
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
						 Português: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br> 
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>
					
					<h5>
					
					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>
					
					</h5>
				</div>
				</div>
			</div>
</div>
		<div class="footer col-lg-12 col-md-12 col-sm-12 col-xs-12">
			
		<div class="container rodape">
			
			<p>Gamificação © - 2017 Powered By Andriele Vogel, Guilherme Cipriano, Marlon Guarniei & Fábio de Moura </p>

		</div>
		</div>

		</body>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</html>