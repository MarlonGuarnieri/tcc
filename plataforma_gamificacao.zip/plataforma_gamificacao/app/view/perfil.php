<!doctype html>
<html lang="en">
<head>
    <link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/fonts/lora.css" rel="stylesheet" type="text/css">
    <link href="../../assets/fonts/montserrat.css" rel="stylesheet" type="text/css">
    <link href="../../assets/css/perfil.css" rel="stylesheet" type="text/css">
    <!------ Include the above in your HEAD tag ---------->



    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="perfil-form"
        <div class="panel panel-primary">
            <div class="panel-heading">  <h4 >Perfil</h4></div>
            <div class="panel-body">
                <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4">
                    <img alt="User Pic" src="https://x1.xingassets.com/assets/frontend_minified/img/users/nobody_m.original.jpg" id="profile-image1" class="img-circle img-responsive">


                </div>
                <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8" >
                    <div class="container" >
                        <h2>Cipriano</h2>
                        <p>an   <b> Employee</b></p>


                    </div>
                    <hr>
                    <ul class="container details" >
                        <li><p><span class="glyphicon glyphicon-user one" style="width:50px;"></span>i.rudberg</p></li>
                        <li><p><span class="glyphicon glyphicon-envelope one" style="width:50px;"></span>somerandom@email.com</p></li>
                    </ul>
                    <hr>
                    <div class="col-sm-5 col-xs-6 tital " >Date Of Joining: 15 Jun 2016</div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>






