<?php

require_once __DIR__."/../model/Login.php";
include_once "painelAdministrador.php";
require_once __DIR__."/../dao/dao_questao.php";
Login::isLogado();

$daoQuestao = new DaoQuestao();
$questoes = $daoQuestao->getQuestoes();


?>

<!DOCTYPE html>
<html lang="en">

<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="author" content="sumit kumar">

<title>admin-template</title>

<link href="../../assets/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">

<link href="../../assets/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css">

<link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">

<!-- CSS Contents -->

<link href="../../assets/css/alunos_cadastrados.css" rel="stylesheet" type="text/css">


<div class="container-fluid">
    <div class="row">

        <section class="content">
            <h1>Questões Cadastradas</h1>
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="pull-right">
                        </div>
                        <div class="table-container">
                            <table class="table my-table-filter">
                                <tbody>
                                <?php foreach($questoes as $questao): ?>

                                <tr>
                                    <td>
                                        <div class="ckbox">
                                            <input type="checkbox" id="checkbox1">
                                            <label for="checkbox1"></label>
                                        </div>
                                    </td>
                                    <td>
                                        <a href="../controller/controlador_aluno.php?acao=excluirAluno&al_idusuario=<?= $questao->getQuIdquestao();?>" class="excluir">
                                            <i class="glyphicon glyphicon-trash"></i>
                                        </a>
                                        <form method="post">
                                            <a href="../view/editar_aluno.php?acao=editar&id=<?= $questao->getQuIdQuestao();?>" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
                                    </td>
                                    <td>
                                        <div class="media">
                                            <div class="media-body">
                                                <span class="media-meta pull-right">Febrero 13, 2016</span>
                                                <h4 class="title">
                                                    <?php echo($questao->getQuTextoquestao());?>
                                                </h4>

                                                Área: <?=$questao->getQuIdarea(); ?>
                                                Ano:  <?=$questao->getQuAno();?>
                                                Nível:<?=$questao->getQuIdnivel();?>
                                                Criador:<?=$questao->getQuIdusuario();?>

                                                <p class="summary">

                                                </p>
                                            </div>
                                        </div>
                                    </td>
                                    <?php endforeach;?>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="content-footer">
                    <p>
                        Gamificação © - 2017 <br>
                        Powered By Fábio De Moura, Guilherme Cipriano & Marlon Guarnieri
                    </p>
                </div>
            </div>
        </section>

    </div>
</div>

<script src="assets/bootrstap/js/jquery-3.1.1.js"></script>
<script src="assets/bootrstap/js/bootstrap.js"></script>
