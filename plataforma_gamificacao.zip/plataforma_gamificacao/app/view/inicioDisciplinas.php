<?php
require_once __DIR__."/../model/Login.php";
include "menu.php"

?>
<!DOCTYPE html>
<html>
<head>
	<title>Progresso</title>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap -->

    <link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/fontawesome-free-5.0.13/web-fonts-with-css/css/fa-brands.min.css"
    <link href="../../assets/fonts/lora.css" rel="stylesheet" type="text/css">
    <link href="../../assets/fonts/montserrat.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/inicioDisciplinas.css">
    <!-- Local -->

</head>
<style type="text/css">

</style>
<body>



<!--disciplinas-->
<div class="conteudo container-fluid">
<div class="row">
    		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-info">
					<div class="shape">
                        <div class="shape-text">

                            <span class= "glyphicon glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                    <div class="offer-content">
                        <h3 class="lead">
                            <i class="fas fa-book"></i>
                            Português: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br>
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>

					<h5>

					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>

					</h5>
				</div>
				</div>
			</div>

			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-info">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
                        <i class="fas fa-calculator"></i>

						 Matemática: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br>
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>

					<h5>

					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>

					</h5>
				</div>
				</div>
			</div>

			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-info">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
                        <i class="fas fa-flask"></i>
						 Ciências: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br>
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>

					<h5>

					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>

					</h5>
				</div>
				</div>
			</div>


		</div>


		<div class="row">
			<div class=" bloco col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="offer offer-info">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
                        <i class="fa fa-handshake-o"></i>
						 Inglês: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br>
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>

					<h5>

					<button class="btn btn-success">Jogar!</button>
					<button class="btn btn-danger">Reforçar!</button>

					</h5>
				</div>
				</div>
			</div>


			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-info">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
                        <i class="fas fa-paint-brush"></i>
						 Artes: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br>
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>

					<h5>

					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>

					</h5>
				</div>
				</div>
			</div>

			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-info">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
                        <i class="fas fa-globe fa-fw"></i>
						 Geografia: <label class="label label-danger">60/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br>
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>

					<h5>

					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>

					</h5>
				</div>
				</div>
			</div>
</div>

<div class="row">
			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
				<div class="bloco offer offer-info">
					<div class="shape">
						<div class="shape-text">
							<span class="glyphicon glyphicon glyphicon-th"></span>
						</div>
					</div>
				<div class="offer-content">
					<h3 class="lead">
                        <i class="fa fa-graduation-cap fa-fw"></i>
						 História: <label class="label label-danger">10/100 Lições </label>
					</h3>
					<p>
						Concluído
						<br>
                        <div class="progress">
             				 <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="60" aria-valuemin="0"
             				aria-valuemax="100" style="width: 60%" >
                   			  60%
            		 </div>
                   </div>
					</p>

					<h5>

					<button class="btn btn-success botao">Jogar!</button>
					<button class="btn btn-danger botao">Reforçar!</button>

					</h5>
				</div>
				</div>
			</div>


		<div class="footer col-lg-12 col-md-12 col-sm-12 col-xs-12">

		<div class="container rodape">

			<p>Gamificação © - 2017 Powered By Andriele Vogel, Guilherme Cipriano, Marlon Guarniei & Fábio de Moura </p>

		</div>
		</div>

		</body>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</html>