<html>
    <head>
    <title>Menu</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap -->

        <link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="../../assets/fonts/lora.css" rel="stylesheet" type="text/css">
        <link href="../../assets/fonts/montserrat.css" rel="stylesheet" type="text/css">
        <link href="../../assets/css/menu.css" rel="stylesheet" type="text/css">


        <!-- Local -->

        <link href="../../assets/css/menu.css">


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>

<body>
<nav class="navbar">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="itens navbar-brand" href="#">TCC</a>
        </div>
        <ul class="nav navbar-nav">

            <li class="dropdown">

            </li>
            <li><a class="itens" id="inicio">Início </a></li>
            <li><a class="itens" id="configuracoes">Configurações</a></li>
            <li><a class="itens" id="perfil">Perfil </a></li>

        </ul>
    </div>
</nav>
</body>

</html>
