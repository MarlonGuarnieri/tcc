<?php

require_once __DIR__."/../model/Login.php";
include_once "painelAdministrador.php";
require_once __DIR__."/../dao/dao_aluno.php";
Login::isLogado();

$daoAluno = new DaoAluno();
$alunos = $daoAluno->getAlunos();


?>

 <!DOCTYPE html>
    <html lang="en">

    <meta charset="utf-8">
	
    <meta name="viewport" content="width=device-width, initial-scale=1"> 	
	
    <meta name="author" content="sumit kumar"> 
	
    <title>admin-template</title> 
	
    <link href="../../assets/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
	
    <link href="../../assets/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css">

	<link href="../../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">

		<!-- CSS Contents -->

	<link href="../../assets/css/alunos_cadastrados.css" rel="stylesheet" type="text/css">

    
    <div class="container-fluid">
	<div class="row">

        <section class="content">
            <h1>Alunos Cadastrados</h1>
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="pull-right">
                        </div>
                        <div class="table-container">
                            <table class="table my-table-filter">
                                <tbody>
                                <?php foreach($alunos as $aluno): ?>

                                <tr>
                                    <td>
                                        <div class="ckbox">
                                            <input type="checkbox" id="checkbox1">
                                            <label for="checkbox1"></label>
                                        </div>
                                    </td>
                                    <td>
                                        <a href="../controller/controlador_aluno.php?acao=excluirAluno&al_idusuario=<?= $aluno->getAlIdusuario();?>" class="excluir">
                                            <i class="glyphicon glyphicon-trash"></i>
                                        </a>
                                        <form method="post">
                                            <a href="../view/editar_aluno.php?acao=editar&id=<?= $aluno->getAlIdusuario();?>" class="editar">
                                                <i class="glyphicon glyphicon-edit"></i>
                                            </a>
                                    </td>
                                    <td>
                                        <div class="media">
                                            <a href="#" class="pull-left">
                                                <img src="https://s3.amazonaws.com/uifaces/faces/twitter/fffabs/128.jpg" class="media-photo">
                                            </a>
                                            <div class="media-body">
                                                <span class="media-meta pull-right">Febrero 13, 2016</span>
                                                <h4 class="title">
                                                    <?php echo($aluno->getUsNome());?>
                                                </h4>

                                                <p class="summary">
                                                    E-mail: <?= $aluno->getUsEmail() ;?>
                                                    Número de Matrícula: <?=$aluno->getAlMatricula();?>
                                                    Data Nascimento: <?= $aluno->getUsDataNascimento();?>
                                                    Ano: <?= $aluno->getAlAno();?>
                                                    Turma: <?= $aluno->getAlTurma();?>
                                                </p>
                                            </div>
                                        </div>
                                    </td>
                                    <?php endforeach;?>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
				<div class="content-footer">
					<p>
						Gamificação © - 2017 <br>
						Powered By Fábio De Moura, Guilherme Cipriano & Marlon Guarnieri
					</p>
				</div>
			</div>
		</section>
		
	</div>
</div>
    
    <script src="assets/bootrstap/js/jquery-3.1.1.js"></script>    
    <script src="assets/bootrstap/js/bootstrap.js"></script>
