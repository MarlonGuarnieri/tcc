<!DOCTYPE html>
<?php
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>

    <!-- Bootstrap Core CSS -->
<!--    <link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">-->

    <!-- Custom Fonts -->
    <!-- <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">

    <!-- Css da Pasta -->
    <link rel="stylesheet" type="text/css" href="../../assets/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/login.css">

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <header class="intro container-fluid">
        <div class="intro-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4 col-md-offset-4">

                        <div class="login-form">
                            <form action="../controller/controlador_login.php?acao=logar" method="post">
                                <h2 class="text-center">Login</h2>
                                <div class="form-group">
                                    <input type="text"     class="form-control" placeholder="Email"    required="required"    name="us_email">
                                </div>

                                <div class="form-group">
                                    <input type="password" class="form-control" placeholder="Senha"      required="required"    name="us_senha">
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                                </div>

                                <div class="clearfix">
                                    <a href="#" class="pull-right">esqueceu a senha?</a>
                                </div>



                            </form>
                            <p class="text-center"><a href="#">Crie uma conta</a></p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>


