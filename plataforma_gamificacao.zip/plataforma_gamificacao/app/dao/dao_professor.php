<?php

    require_once __DIR__.'/../database/conexao.php';
    require_once __DIR__.'/../model/Professor.php';

    class DaoProfessor{

        private $conexao = null;

        function __construct()
        {

            $this->conexao = Conexao::getConexao();
        }

        public function cadastrarProfessor(Professor $professor)
        {
            $sql = "INSERT INTO `usuario` (`us_nome`, `us_email`, `us_senha`, `us_datanascimento`) VALUES ('{$professor->getUsNome()}', '{$professor->getUsEmail()}', '{$professor->getUsSenha()}', '{$professor->getUsDatanascimento()}')";
//
            $this->conexao->exec($sql);

            $sql = "INSERT INTO `professor` (`pr_idusuario`, `pr_matricula`, `pr_area`) VALUES ({$this->conexao->lastInsertId()}, '{$professor->getPrMatricula()}', '{$professor->getPrArea()}')";


            $this->conexao->exec($sql);

        }

        public function editarProfessor(Professor $professor)
        {

            $sql = ("UPDATE `usuario` SET `us_nome` = '{$professor->getUsNome()}', `us_email` = '{$professor->getUsEmail()}', `us_senha` = '{$professor->getUsSenha()}', `us_datanascimento` = '{$professor->getUsDatanascimento()}' WHERE `usuario`.`us_idusuario` = {$professor->getPrIdusuario()} ");

            $this->conexao->exec($sql);
            $sql = ("UPDATE `professor` SET `pr_matricula` = '{$professor->getPrMatricula()}',`pr_area` = '{$professor->getPrArea()}' WHERE `professor`.`pr_idusuario` = {$professor->getPrIdusuario()}");

            $this->conexao->exec($sql);
        }

        public function deletarProfessor($id)
        {

            $sql = ("DELETE FROM `professor` WHERE `professor`.`pr_idusuario` = $id");

            $this->conexao->exec($sql);

            $sql = ("DELETE FROM `usuario` WHERE `usuario`.`us_idusuario` = $id");

            $this->conexao->exec($sql);
        }

        public function getProfessor($pr_idusuario)
        {

            $sql = ("SELECT * FROM `professor`, `usuario` WHERE us_idusuario = $pr_idusuario AND pr_idusuario = $pr_idusuario ");

            $professor = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);


            return new Professor($professor['us_idusuario'],
                                 $professor['us_nome'],
                                 $professor['us_email'],
                                 $professor['us_senha'],
                                 $professor['us_datanascimento'],
                                 $professor['pr_idusuario'],
                                 $professor['pr_matricula'],
                                 $professor['pr_area']);
        }

        public function getProfessores(){

            $sql = ("SELECT * FROM usuario, professor WHERE us_idusuario = pr_idusuario");

            $professores = $this->conexao->query($sql)->fetchAll(PDO::FETCH_ASSOC);

            $listaProfessores = [];

            foreach ($professores as $professor) {

                $listaProfessores[] = new Professor($professor['us_idusuario'],
                    $professor['us_nome'],
                    $professor['us_email'],
                    $professor['us_senha'],
                    $professor['us_datanascimento'],
                    $professor['pr_idusuario'],
                    $professor['pr_matricula'],
                    $professor['pr_area']);


            }

            return $listaProfessores;
        }

    }