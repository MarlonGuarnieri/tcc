<?php

    require_once __DIR__.'/../database/conexao.php';
    require_once __DIR__.'/../model/Professor.php';

    class DaoProfessor
    {

        private $conexao = null;

        function __construct()
        {

            $this->conexao = Conexao::getConexao();
        }

        public function cadastrarProfessor(Professor $professor)
        {
            $sql = "INSERT INTO `usuario` (`us_nome`, `us_email`, `us_senha`, `us_datanascimento`) VALUES ('{$professor->getUsNome()}', '{$professor->getUsEmail()}', '{$professor->getUsSenha()}', '{$professor->getUsDatanascimento()}')";
//
            $this->conexao->exec($sql);

            $sql = "INSERT INTO `professor` (`pr_idusuario`, `pr_matricula`, `pr_area`) VALUES ({$this->conexao->lastInsertId()}, '{$professor->getPrMatricula()}', '{$professor->getPrArea()}')";


            $this->conexao->exec($sql);

        }

        public function editarProfessor($us_idusuario, $us_nome, $us_email, $us_senha, $us_datanascimento, $pr_area)
        {

            $sql = ("UPDATE `usuario` SET `us_nome` = '{$us_nome}', `us_email` = '{$us_email}', `us_senha` = '{$us_senha}', `us_datanascimento` = '{$us_datanascimento}' WHERE `usuario`.`us_idusuario` = {$us_idusuario} ");

            $this->conexao->exec($sql);

            $sql = ("UPDATE `professor` SET  `pr_area` = '{$pr_area}' WHERE `professor`.`pr_idusuario` = {$us_idusuario}");

            $this->conexao->exec($sql);
        }

        public function deletarProfessor($id)
        {

            $sql = ("DELETE FROM `professor` WHERE `professor`.`pr_idusuario` = $id");

            $this->conexao->exec($sql);

            $sql = ("DELETE FROM `usuario` WHERE `usuario`.`us_idusuario` = $id");

            $this->conexao->exec($sql);
        }

        public function getProfessor($id)
        {

            $sql = ("SELECT * FROM `professor`, `usuario` WHERE us_idusuario = $id AND pr_idusuario = $id ");

            $consulta = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);


            return new Professor($consulta['us_idusuario'],
                                 $consulta['us_nome'],
                                 $consulta['us_email'],
                                 $consulta['us_senha'],
                                 $consulta['us_datanascimento'],
                                 $consulta['pr_idusuario'],
                                 $consulta['pr_matricula'],
                                 $consulta['pr_area']);
        }

        public function getProfessores(){

            $sql = ("SELECT * FROM usuario, professor WHERE us_idusuario = pr_idusuario");

            $consulta = $this->conexao->query($sql)->fetchAll(PDO::FETCH_ASSOC);

            $listaProfessores = [];

            foreach ($consulta as $dados) {

                $listaProfessores[] = new Professor($dados['us_idusuario'],
                    $dados['us_nome'],
                    $dados['us_email'],
                    $dados['us_senha'],
                    $dados['us_datanascimento'],
                    $dados['pr_idusuario'],
                    $dados['pr_matricula'],
                    $dados['pr_area']);


            }

            return $listaProfessores;
        }

        public function excluirProfessor($pr_idusuario){
            $sql = ("DELETE FROM professor where pr_idusuario = $pr_idusuario");

            $this->conexao->exec($sql);

            $sql = ("DELETE FROM usuario where us_idusuario = $pr_idusuario");

            $this->conexao->exec($sql);
        }
    }
