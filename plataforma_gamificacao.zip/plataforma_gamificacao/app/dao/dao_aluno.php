<?php

require_once __DIR__.'/../database/conexao.php';
require_once __DIR__.'/../model/Aluno.php';

class DaoAluno
{

    private $conexao = null;

    function __construct()
    {

        $this->conexao = Conexao::getConexao();

    }

    public function cadastrarAluno(Aluno $aluno)
    {
        $sql = "INSERT INTO `usuario` (`us_nome`, `us_email`, `us_senha`, `us_datanascimento`) VALUES ('{$aluno->getUsNome()}', '{$aluno->getUsEmail()}', '{$aluno->getUsSenha()}', '{$aluno->getUsDatanascimento()}')";

        $this->conexao->exec($sql);

        $sql = "INSERT INTO `aluno` (`al_idusuario`, `al_matricula`, `al_ano`, `al_turma` ) VALUES ({$this->conexao->lastInsertId()}, '{$aluno->getAlMatricula()}', '{$aluno->getAlAno()}', '{$aluno->getAlTurma()}')";

        $this->conexao->exec($sql);

    }

    public function editarAluno(Aluno $aluno)
    {

        $sql = ("UPDATE `usuario` SET `us_nome` = '{$aluno->getUsNome()}', `us_email` = '{$aluno->getUsEmail()}', `us_senha` = '{$aluno->getUsSenha()}', `us_datanascimento` = '{$aluno->getUsDatanascimento()}' WHERE `usuario`.`us_idusuario` = {$aluno->getUsIdusuario()} ");

        $this->conexao->exec($sql);

        $sql = ("UPDATE `aluno` SET `al_matricula` = '{$aluno->getAlMatricula()}', `al_ano` = '{$aluno->getAlAno()}', `al_turma` = '{$aluno->getAlTurma()}'   WHERE `aluno`.`al_idusuario` = {$aluno->getAlIdusuario()}");

        $this->conexao->exec($sql);
    }

    public function deletarAluno($id)   {

        $sql = ("DELETE FROM `aluno` WHERE `aluno`.`al_idusuario` = $id");

        $this->conexao->exec($sql);

        $sql = ("DELETE FROM `usuario` WHERE `usuario`.`al_idusuario` = $id");

        $this->conexao->exec($sql);
    }

    public function getAluno($id){

        $sql = ("SELECT * FROM usuario, aluno WHERE us_idusuario = $id and al_idusuario = $id");

        $aluno = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);

        return new Aluno($aluno['us_idusuario'],
                         $aluno['us_nome'],
                         $aluno['us_email'],
                         $aluno['us_senha'],
                         $aluno['us_datanascimento'],
                         $aluno['al_idusuario'],
                         $aluno['al_matricula'],
                         $aluno['al_ano'],
                         $aluno['al_turma']);

    }

    public function getAlunos(){

        $sql = ("SELECT * FROM usuario, aluno WHERE al_idusuario = us_idusuario");

        $alunos = $this->conexao->query($sql)->fetchAll(PDO::FETCH_ASSOC);


        $listaAlunos = [];

        foreach ($alunos as $aluno){

            $listaAlunos[] = new Aluno( $aluno['us_idusuario'],
                                        $aluno['us_nome'],
                                        $aluno['us_email'],
                                        $aluno['us_senha'],
                                        $aluno['us_datanascimento'],
                                        $aluno['al_idusuario'],
                                        $aluno['al_matricula'],
                                        $aluno['al_ano'],
                                        $aluno['al_turma']);



        }

        return $listaAlunos;

    }

    public function excluirAluno($al_idusuario){
        $sql = ("DELETE FROM aluno where al_idusuario = $al_idusuario");

        $this->conexao->exec($sql);

        $sql = ("DELETE FROM usuario where us_idusuario = $al_idusuario");

        $this->conexao->exec($sql);
    }
}
