<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 04/05/2018
 * Time: 16:10
 */
    require_once __DIR__.'/../database/conexao.php';
    require_once __DIR__.'/../model/Questao.php';

    class DaoQuestao{

        private $conexao = null;

        function __construct(){

            $this->conexao = Conexao::getConexao();
        }

        public function cadastrarQuestao(Questao $questao){

            $sql = ("INSERT INTO `questao` (`qu_idquestao`, `qu_idarea`, `qu_ano`, `qu_idnivel`, `qu_idusuario`, `qu_textoquestao`) VALUES (NULL, '{$questao->getQuIdarea()}', '{$questao->getQuAno()}', '{$questao->getQuIdnivel()}', '{$questao->getQuIdusuario()}', '{$questao->getQuTextoquestao()}') ");

            $this->conexao->exec($sql);
        }


        public function editarQuestao(Questao $questao){

            $sql = ("UPDATE `questao` SET `qu_idarea` = '{$questao->getQuIdarea()}', `qu_ano` = '{$questao->getQuAno()}', `qu_idnivel` = '{$questao->getQuIdnivel()}}', `qu_idusuario` = '{$questao->getQuIdusuario()}', `qu_textoquestao` = '{$questao->getQuTextoquestao()}' WHERE `questao`.`qu_idquestao` = {$questao->getQuIdquestao()}");

            $this->conexao->exec($sql);
        }

        public function excluirQuestao($qu_idquestao){
            $sql = ("DELETE FROM questao WHERE qu_idquestao = $qu_idquestao");

            $this->conexao->exec($sql);
        }

        public function getQuestao($qu_idquestao){
            $sql = ("SELECT * FROM questao WHERE qu_idquestao = $qu_idquestao");

            $questao = $this->conexao->query($sql)->fetch(PDO:: FETCH_ASSOC);

            return new Questao($questao['qu_idquestao'],
                               $questao['qu_idarea'],
                               $questao['qu_ano'],
                               $questao['qu_idnivel'],
                               $questao['qu_idusuario'],
                               $questao['qu_textoquestao']);
        }

        public function getQuestoes()
        {

            $sql = ("SELECT * FROM questao");

            $questoes = $this->conexao->query($sql)->fetchAll(PDO::FETCH_ASSOC);

            $questaoLista = [];

            foreach ($questoes as $questao) {

                $questaoLista[] = new Questao($questao['qu_idquestao'],
                                              $questao['qu_idarea'],
                                              $questao['qu_ano'],
                                              $questao['qu_idnivel'],
                                              $questao['qu_idusuario'],
                                              $questao['qu_textoquestao']);

            }

            return $questaoLista;
        }

    }