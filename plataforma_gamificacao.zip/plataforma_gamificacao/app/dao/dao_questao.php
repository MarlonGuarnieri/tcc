<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 04/05/2018
 * Time: 16:10
 */
    require_once __DIR__.'/../database/conexao.php';
    require_once __DIR__.'/../model/Questao.php';

    class DaoQuestao{

        private $conexao = null;

        function __construct(){

            $this->conexao = Conexao::getConexao();
        }

        public function cadastrarQuestao(Questao $questao){

            $sql = "";

            $this->conexao->exec($sql);
        }
    }