<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 04/05/2018
 * Time: 16:03
 */


class Questao
{
    private $qu_idquestao ;
    private $qu_idarea;
    private $qu_ano;
    private $qu_idnivel;
    private $qu_idusuario;
    private $qu_textoquestao;

    public function __construct()
    {
    }

    public function getQuIdquestao()
    {
        return $this->qu_idquestao;
    }

    public function setQuIdquestao($qu_idquestao)
    {
        $this->qu_idquestao = $qu_idquestao;
    }

    public function getQuIdarea()
    {
        return $this->qu_idarea;
    }

    public function setQuIdarea($qu_idarea)
    {
        $this->qu_idarea = $qu_idarea;
    }

    public function getQuAno()
    {
        return $this->qu_ano;
    }

    public function setQuAno($qu_ano)
    {
        $this->qu_ano = $qu_ano;
    }

    public function getQuIdnivel()
    {
        return $this->qu_idnivel;
    }

    public function setQuIdnivel($qu_idnivel)
    {
        $this->qu_idnivel = $qu_idnivel;
    }

    public function getQuIdusuario()
    {
        return $this->qu_idusuario;
    }

    public function setQuIdusuario($qu_idusuario)
    {
        $this->qu_idusuario = $qu_idusuario;
    }

    public function getQuTextoquestao()
    {
        return $this->qu_textoquestao;
    }

    public function setQuTextoquestao($qu_textoquestao)
    {
        $this->qu_textoquestao = $qu_textoquestao;
    }



}