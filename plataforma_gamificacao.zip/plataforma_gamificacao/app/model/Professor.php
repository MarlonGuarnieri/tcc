<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 10/04/2018
 * Time: 14:04
 */

    require_once __DIR__.'/Usuario.php';

class Professor extends Usuario{

    private $pr_idusuario;
    private $pr_matricula;
    private $pr_area;

    public function __construct($us_idusuario = null, $us_nome, $us_email, $us_senha, $us_datanascimento, $pr_idusuario, $pr_matricula, $pr_area){

        $this->setUsIdusuario($us_idusuario);
        $this->setUsNome($us_nome);
        $this->setUsEmail($us_email);
        $this->setUsNome($us_nome);
        $this->setUsSenha($us_senha);
        $this->setUsDatanascimento($us_datanascimento);
        $this->pr_idusuario = $pr_idusuario;
        $this->pr_matricula = $pr_matricula;
        $this->pr_area      = $pr_area;


    }

    public function getPrIdusuario()
    {
        return $this->pr_idusuario;
    }

    public function setPrIdusuario($pr_idusuario)
    {
        $this->pr_idusuario = $pr_idusuario;
    }

    public function getPrMatricula()
    {
        return $this->pr_matricula;
    }

    public function setPrMatricula($pr_matricula)
    {
        $this->pr_matricula = $pr_matricula;
    }

    public function getPrArea()
    {
        return $this->pr_area;
    }

    public function setPrArea($pr_area)
    {
        $this->pr_area = $pr_area;
    }


}