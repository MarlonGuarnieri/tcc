<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 10/04/2018
 * Time: 14:00
 */

class Usuario{

    private $us_idusuario;
    private $us_nome;
    private $us_email;
    private $us_senha;
    private $us_datanascimento;

    public function getUsIdusuario()
    {
        return $this->us_idusuario;
    }

    public function setUsIdusuario($us_idusuario)
    {
        $this->us_idusuario = $us_idusuario;
    }

    public function getUsNome()
    {
        return $this->us_nome;
    }

    public function setUsNome($us_nome)
    {
        $this->us_nome = $us_nome;
    }

    public function getUsEmail()
    {
        return $this->us_email;
    }

    public function setUsEmail($us_email)
    {
        $this->us_email = $us_email;
    }

    public function getUsSenha()
    {
        return $this->us_senha;
    }

    public function setUsSenha($us_senha)
    {
        $this->us_senha = $us_senha;
    }

    public function getUsDatanascimento()
    {
        return $this->us_datanascimento;
    }

    public function setUsDatanascimento($us_datanascimento)
    {
        $this->us_datanascimento = $us_datanascimento;
    }



}