<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 24/04/2018
 * Time: 08:15
 */

    require_once __DIR__.'/Usuario.php';

class Aluno extends Usuario
{
    private $al_idusuario;
    private $al_matricula;
    private $al_ano;
    private $al_turma;

    public function __construct($us_idusuario = null, $us_nome, $us_email, $us_senha, $us_datanascimento, $al_idusuario = null, $al_matricula, $al_ano, $al_turma){

        $this->setUsIdusuario($us_idusuario);
        $this->setUsNome($us_nome);
        $this->setUsEmail($us_email);
        $this->setUsNome($us_nome);
        $this->setUsSenha($us_senha);
        $this->setUsDatanascimento($us_datanascimento);
        $this->al_idusuario = $al_idusuario;
        $this->al_matricula = $al_matricula;
        $this->al_ano       = $al_ano;
        $this->al_turma     = $al_turma;


    }

    public function getAlIdusuario()
    {
        return $this->al_idusuario;
    }

    public function setAlIdusuario($al_idusuario)
    {
        $this->al_idusuario = $al_idusuario;
    }

    public function getAlMatricula()
    {
        return $this->al_matricula;
    }

    public function setAlMatricula($al_matricula)
    {
        $this->al_matricula = $al_matricula;
    }

    public function getAlAno()
    {
        return $this->al_ano;
    }

    public function setAlAno($al_ano)
    {
        $this->al_ano = $al_ano;
    }

    public function getAlTurma()
    {
        return $this->al_turma;
    }

    public function setAlTurma($al_turma)
    {
        $this->al_turma = $al_turma;
    }


}