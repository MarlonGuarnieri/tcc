<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 27/04/2018
 * Time: 16:04
 */

require_once __DIR__.'/../database/conexao.php';
session_start();

class Login {

    private $conexao = null;

    function __construct() {

        $this->conexao = Conexao::getConexao();

    }

    public function logar($email, $senha){

        $usuario = $this->conexao->query("select * from usuario WHERE us_email = '$email' AND us_senha = '$senha'")->fetch(PDO::FETCH_ASSOC);
        if (count($usuario) == 0){
            return false;
        } elseif($email = $usuario['us_email']  and $senha == $usuario['us_senha']){

            header('Location: ../view/painelAdministrador.php');
           return $_SESSION['usuario_id'] = $usuario['us_idusuario'];


        }
    }

    public static function isLogado(){

        if (!isset($_SESSION['usuario_id'])){

            header("Location: ../view/login.php");

        } else{
        }

    }

    public function deslogar(){

        session_destroy();


    }
}