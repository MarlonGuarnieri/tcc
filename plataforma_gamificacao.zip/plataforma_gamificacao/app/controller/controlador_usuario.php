<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 09/05/2018
 * Time: 14:39
 */
require_once __DIR__.'/../model/Login.php';
Login::isLogado();

function index(){
    include_once __DIR__.'/../view/inicioDisciplinas.php';
}



if (!empty($_GET['acao']) && isset($_GET['acao'])){

    $acao = $_GET['acao'];

    if ($acao == 'cadastrarProfessor'){
        header('Location: controlador_professor.php?acao=cadastrarProfessor');

    } elseif($acao == 'cadastrarAluno') {
        header('Location: controlador_aluno.php?acao=cadastrarAluno');

    } elseif ($acao == 'editar'){

        $id = $_GET['id'];
        header("Location: ../view/editar_professor.php?id=$id");

    } elseif($acao == 'editarProfessor'){
        editarProfessor();
        header('Location: ../view/professores_cadastrados.php');
    }

}else {
    //chama funcao index
    index();
}