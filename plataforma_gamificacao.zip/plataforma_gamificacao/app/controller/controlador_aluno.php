<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 09/05/2018
 * Time: 14:36
 */

require_once __DIR__.'/../dao/dao_aluno.php';
require_once __DIR__.'/../model/Login.php';
Login::isLogado();

function index(){
    include_once __DIR__.'/../view/progresso.php';
}

function cadastrarAluno(){
    $us_nome            = $_POST['us_nome'];
    $us_email           = $_POST['us_email'];
    $us_senha           = $_POST['us_senha'];
    $us_datanascimento  = $_POST['us_datanascimento'];
    $al_matricula       = $_POST['al_matricula'];
    $al_turma           = $_POST['al_turma'];
    $al_ano             = $_POST['al_ano'];

    $aluno = new Aluno(null,null,null,null,null,null,null,null,null);
    $aluno->setUsNome($us_nome);
    $aluno->setUsEmail($us_email);
    $aluno->setUsSenha($us_senha);
    $aluno->setUsDatanascimento($us_datanascimento);
    $aluno->setAlMatricula($al_matricula);
    $aluno->setAlAno($al_ano);
    $aluno->setAlTurma($al_turma);

    $daoProfessor = new DaoAluno();
    $daoProfessor->cadastrarAluno($aluno);

}

function editarAluno(){
    $us_idusuario       = $_POST['us_idusuario'];
    $us_nome            = $_POST['us_nome'];
    $us_email           = $_POST['us_email'];
    $us_senha           = $_POST['us_senha'];
    $us_datanascimento  = $_POST['us_datanascimento'];
    $al_matricula       = $_POST['al_matricula'];
    $al_turma           = $_POST['al_turma'];
    $al_ano             = $_POST['al_ano'];

    $aluno = new Aluno(null, null, null, null, null, null, null, null, null);
    $aluno->setUsNome($us_nome);
    $aluno->setUsEmail($us_email);
    $aluno->setUsSenha($us_senha);
    $aluno->setUsDatanascimento($us_datanascimento);
    $aluno->setAlMatricula($al_matricula);
    $aluno->setAlAno($al_ano);
    $aluno->setAlTurma($al_turma);

    $daoProfessor = new DaoAluno();
    $daoProfessor->cadastrarAluno($aluno);

}

function excluirAluno(){
    $al_idusuario = $_GET['al_idusuario'];

    $aluno = new DaoAluno();
    $aluno->excluirAluno($al_idusuario);

}


if (!empty($_GET['acao']) && isset($_GET['acao'])) {

    $acao = $_GET['acao'];

    if ($acao == 'cadastrarAluno'){
        cadastrarAluno();
    }elseif($acao == 'editarAluno'){
        editarAluno();
    }elseif($acao == 'excluirAluno'){
        excluirAluno();
        header('Location: ../view/alunos_cadastrados.php');
    }
}
