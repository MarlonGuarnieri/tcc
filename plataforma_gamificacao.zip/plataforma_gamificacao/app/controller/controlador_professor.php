<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 10/04/2018
 * Time: 08:56
 */

require_once __DIR__.'/../dao/dao_professor.php';
require_once __DIR__.'/../model/Login.php';
function cadastrarProfessor()
{
    $us_nome           = $_POST['us_nome'];
    $us_email          = $_POST['us_email'];
    $us_senha          = $_POST['us_senha'];
    $us_datanascimento = $_POST['us_datanascimento'];
    $pr_matricula      = $_POST['pr_matricula'];
    $pr_area           = $_POST['pr_area'];


    $professor = new Professor(null,$us_nome,$us_email,$us_senha,$us_datanascimento,null,$pr_matricula,$pr_area);

    $daoProfessor = new DaoProfessor();
    $daoProfessor->cadastrarProfessor($professor);

}

function editarProfessor(){
    $us_idusuario      = $_POST['us_idusuario'];
    $us_nome           = $_POST['us_nome'];
    $us_email          = $_POST['us_email'];
    $us_senha          = $_POST['us_senha'];
    $us_datanascimento = $_POST['us_datanascimento'];
    $pr_matricula      = $_POST['pr_matricula'];
    $pr_area           = $_POST['pr_area'];

    $professor = new Professor($us_idusuario,$us_nome,$us_email,$us_senha,$us_datanascimento,$us_idusuario,$pr_matricula,$pr_area);
    $daoProfessor = new DaoProfessor();
    $daoProfessor->editarProfessor($professor);
}

function excluirProfessor(){
    $us_idusuario = $_GET['pr_idusuario'];
    $pr_idusuario = $us_idusuario;

    $professor = new DaoProfessor();
    $professor->deletarProfessor($pr_idusuario);

}

if (!empty($_GET['acao']) && isset($_GET['acao'])) {

    $acao = $_GET['acao'];

    if ($acao == 'cadastrarProfessor'){
        cadastrarProfessor();
        header('Location:../view/painelAdministrador.php');

    } elseif($acao == 'editarProfessor'){
        editarProfessor();
        header('Location: ../view/painelAdministrador.php');

    }elseif ($acao == 'excluirProfessor'){

        excluirProfessor();
        header('Location: ../view/professores_cadastrados.php');
    }

}
