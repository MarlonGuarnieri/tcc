<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Cipriano
 * Date: 10/04/2018
 * Time: 08:56
 */
require_once __DIR__.'/../model/Login.php';
$login = new Login();
//mostrar form de login

if ($_GET['acao'] == "logar"){
    $login->logar($_POST['us_email'], $_POST['us_senha']);
}

// receber os dados do form de login e verificar se estao corretos, se deu certo, grava na sessao e redireciona