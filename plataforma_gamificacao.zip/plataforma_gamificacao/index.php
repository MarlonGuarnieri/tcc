<?php

    const MAIN_CONTROLLER = 'controlador_usuario.php';


    header('location: app/controller/' . MAIN_CONTROLLER);