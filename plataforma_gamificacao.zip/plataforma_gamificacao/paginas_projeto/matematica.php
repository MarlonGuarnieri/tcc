<!DOCTYPE html>
<html>
<head>
 	<title>Matemática</title>

	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

	<!-- Bootstrap -->

    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/fonts/lora.css" rel="stylesheet" type="text/css">
    <link href="assets/fonts/montserrat.css" rel="stylesheet" type="text/css">
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- Local -->
	
	<link href="assets/css/progresso.css" rel="stylesheet" type="text/css">


</head>
 <body>
 <div class="container-fluid col-md-12">
     <div id="lateral">
         <div id="menu">
             <div class="row profile container-fluid">
                 <div class="col-sm-12">

                     <!-- SIDEBAR USERPIC -->
                     <div class="profile-userpic">
                         <img src="https://yt3.ggpht.com/-Mkzp5zptlJU/AAAAAAAAAAI/AAAAAAAAAAA/blLjbZhAFoA/s900-c-k-no-mo-rj-c0xffffff/photo.jpg" class="img-responsive" alt="">
                     </div>
                     <!-- END SIDEBAR USERPIC -->
                     <!-- SIDEBAR USER TITLE -->
                     <div class="profile-usertitle">
                         <div class="profile-usertitle-name">
                             Guilherme Cipriano
                         </div>
                         <div class="profile-usertitle-job">
                             2info1
                             <br>
                             <i class="fa fa-btc"></i>50 Cipricoins
                         </div>
                     </div>
                     <!-- END SIDEBAR USER TITLE -->
                     <!-- SIDEBAR BUTTONS -->

                     <!-- END SIDEBAR BUTTONS -->
                     <!-- SIDEBAR MENU -->
                     <div class="profile-usermenu accordion">
                         <ul class="nav">
                             <li>
                                 <a href="progresso.php">
                                     <i class="glyphicon glyphicon-home"></i>
                                     Início </a>

                             </li>
                             <li>
                                 <a href="perfil.php">
                                     <i class="glyphicon glyphicon-user"></i>
                                     Perfil </a>

                             </li>
                             <li class= "accordion-item">
                                 <a href="#">
                                     <i class = "glyphicon glyphicon-list"></i>
                                     Ranking </a>
                                 <div  class="accordion-item-content">
                                     <ul>
                                         <li><a href="../app/view/ranking.php">
                                                 <i class="fa fa-users"></i>
                                                 Turma</a>
                                         </li>

                                         <li><a href="../app/view/ranking.php">
                                                 <i class="fa fa-fort-awesome"></i>
                                                 Insituição</a></li>


                                         <li><a href="../app/view/ranking.php">
                                                 <i class="fa fa-university"></i>
                                                 Escolas
                                             </a>
                                         </li>

                                     </ul>
                                 </div>

                             </li>


                             <li class= "accordion-item" id="materias">
                                 <a href="#" target="_blank">
                                     <i class="glyphicon glyphicon-fire"></i>
                                     Modo de Jogo </a>
                                 <div  class="accordion-item-content">
                                     <ul>
                                         <li>
                                             <a href="duelo.php">
                                                 <i class= "glyphicon glyphicon-flash"></i>
                                                 Duelo</a>

                                         </li>
                                     </ul>
                                 </div>

                             </li>
                             <li class= "accordion-item">
                                 <a href="#">
                                     <i class = "glyphicon glyphicon-list"></i>
                                     Disciplinas </a>
                                 <div  class="accordion-item-content" id="ac2">
                                     <ul>
                                         <li>
                                             <a href="portugues.php">
                                                 <i class="glyphicon glyphicon-book"></i>
                                                 Português</a>
                                         </li>

                                         <li>
                                             <a href="matematica.php">
                                                 <i class="glyphicon glyphicon-plus"></i>
                                                 Matemática</a>
                                         </li>

                                         <li>
                                             <a href="ciencias.php">
                                                 <i class="fa fa-flask"></i>
                                                 Ciências</a>
                                         </li>

                                         <li><a href="historia.php">
                                                 <i class="glyphicon glyphicon-hourglass"></i>
                                                 História</a>
                                         </li>

                                         <li><a href="geografia.php">
                                                 <i class="glyphicon glyphicon-globe"></i>
                                                 Geografia</a>
                                         </li>

                                         <li><a href="ingles.php">
                                                 <i class="glyphicon glyphicon-pencil"></i>
                                                 Inglês</a>
                                         </li>

                                         <li><a href="artes.php">
                                                 <i class="glyphicon glyphicon-tint"></i>
                                                 Artes</a>
                                         </li>

                                         <li><a href="educacao-fisica.php">
                                                 <i class="glyphicon glyphicon-heart-empty"></i>
                                                 Ed.Física</a>
                                         </li>
                                     </ul>
                                 </div>

                             </li>
                             <li>
                                 <a href="configuracoes.php"">
                                 <i class="glyphicon glyphicon-cog"></i>
                                 Configurações</a>
                             </li>


                             <li>
                                 <a href="loja.php">
                                     <i class="glyphicon glyphicon-shopping-cart"></i>
                                     Compras </a>

                             </li>
                             <li>
                                 <a href="conquistas.php">
                                     <i class="glyphicon glyphicon-star"></i>
                                     Conquistas </a>

                             </li>
                             <li>
                                 <a href="ajuda.php">
                                     <i class="glyphicon glyphicon-question-sign"></i>
                                     Ajuda </a>
                             </li>
                             <li>
                                 <a href="index.php">
                                     <i class="glyphicon glyphicon-share-alt"></i>
                                     Sair </a>

                             </li>
                         </ul>
                     </div>
                 </div>
             </div>
         </div>
     </div>

				<h1 style="text-align: center">Matemática</h1>
 <!--Assunto 1-->
 <div class="col-md-12 principal">
            <div class="profile-content">
            <div class="row">
    		    <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
            <div class="offer offer-success">
                <div class="offer-content">
                    <h3 class="lead">
                         Primeiro Ano
                    </h3>
                    <p>
                        Concluído
                        <br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
                    </p>
                    <h5>
                    <a class="btn btn-success" href="matematica-primeiro-ano-assuntos.php">Jogar!</a>
                    
                    </h5>
                </div>
            </div>
        </div>

         <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
            <div class="offer offer-success">
                <div class="offer-content">
                    <h3 class="lead">
                         Segundo Ano
                    </h3>
                    <p>
                        Concluído
                        <br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
                    </p>
                    <h5>
                    <button class="btn btn-success">Jogar!</button>
                    </h5>
                </div>
            </div>
        </div>

         <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
            <div class="offer offer-success">
                <div class="offer-content">
                    <h3 class="lead">
                         Terceiro Ano
                    </h3>
                    <p>
                        Concluído
                        <br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
                    </p>
                    <h5>
                    <button class="btn btn-success">Jogar!</button>
                    
                    </h5>
                </div>
            </div>
        </div>

         <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
            <div class="offer offer-success">
                <div class="offer-content">
                    <h3 class="lead">
                         Quarto Ano
                    </h3>
                    <p>
                        Concluído
                        <br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
                    </p>
                    <h5>
                    <button class="btn btn-success">Jogar!</button>
                    
                    </h5>
                </div>
            </div>
        </div>

         <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
            <div class="offer offer-success">
                <div class="offer-content">
                    <h3 class="lead">
                         Quinto Ano
                    </h3>
                    <p>
                        Concluído
                        <br> 
                        <div class="progress">
             <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%" >
                     60%
                        </div>
                   </div>
                    </p>
                    <h5>
                    <button class="btn btn-success">Jogar!</button>
                    
                    </h5>
                </div>
            </div>
        </div>
	</div>
</div>
</div>
	</body>
 </html>